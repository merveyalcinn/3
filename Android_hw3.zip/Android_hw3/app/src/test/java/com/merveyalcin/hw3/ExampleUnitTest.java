module counter(clk,counter);
	input clk;
	output reg counter[15:0];
	reg clock[25:0];
	
	always @(posedge clk)
	begin
	clock <= clock +1;
	end
	
	always @(clock[25])
	begin
	counter <= counter+1;
	end
	
	initial begin
	counter=0;
	clock=0;
	end
	
endmodule