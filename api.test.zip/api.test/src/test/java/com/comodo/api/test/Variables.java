package com.comodo.api.test;

public abstract class Variables {
	
	/**TESTRAIL**/
	protected static final String TESTRAIL_URL = "http://testrail.brad.dc.comodo.net/";
	protected static final String TESTRAIL_USER = "dilara.atesogullari@comodo.com";
	protected static final String TESTRAIL_PASS = "IdtyQP10A";

}
