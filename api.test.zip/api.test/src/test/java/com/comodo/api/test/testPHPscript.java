package com.comodo.api.test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import org.testng.Reporter;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;

import org.testng.annotations.Test;
import com.jayway.restassured.response.Response;
import junit.framework.Assert;

import com.comodo.api.test.TestRailIntegration;
import com.comodo.api.test.testRail_APIException;


//import static com.jayway.restassured.RestAssured.given;

public class testPHPscript extends PHPscript{
	
	@AfterMethod
    public void afterMethod(ITestResult result)
    {

	   
    	TestRailIntegration test = new TestRailIntegration(TESTRAIL_USER,TESTRAIL_PASS);
    	String case_id = result.getAttribute(result.getName()).toString();
        try
     {
        if(result.getStatus() == ITestResult.SUCCESS)
        {

        	test.setResultToTestRail("63641", case_id, 1, "Passed in automation successfully");
        	System.out.println("Pass");
        
        
        }

        else if(result.getStatus() == ITestResult.FAILURE)
        {
        	test.setResultToTestRail("63641", case_id, 5, "Failed in automation");
      

        }

         else if(result.getStatus() == ITestResult.SKIP ){

        	test.setResultToTestRail("63641", case_id, 3, "Skipped in automation");
        	

        }
    }
       catch(Exception e)
       {
         e.printStackTrace();
       }

    }
	
	
	
	//------------PATCH > UPDATE PHP SCRIPT PATH
	 @Test (priority = 1)
	  public void testPatchUpdatePHPScriptPath(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
	   
		  Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7125200");
		  
		  String api_url = " http://service.cwatch.com/domains/eWV0YW5vdGhlcnNpdGUudXM=";
		  String api_body = "{\"customer\": {\"cam_id\":\"885829\"}, \"domain\": {\"php_path\": \"http://yetanothersite.us/yetanothersite.us_1508830035547.php\",\"auto_malware_removal\": true}}";
		  
		  Response response = callPatchMethod(api_body,api_url);
		  String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
		  int statusCode = response.statusCode();
		  String statusName = response.statusLine();
		  System.out.println("RESULT PatchUpdateWebsite: "+result);
		  System.out.println("STATUS CODE : "+statusCode);
		  System.out.println("STATUS NAME : "+statusName+"\n");
		  
		  Assert.assertEquals("HTTP/1.1 200 OK",statusName);
	     
	  }
	  
	
	
	//---------GetDomainMalwareScanningReport
	
	@Test (priority = 2)
	  public void testGetDomainMalwareScanningReport(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
		
			Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7125206");
		  
		    String url = "http://service.cwatch.com/domains/1502/reports?type=1";
		   
		    Response response = callGetMethodPHP(url);
			String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
			int statusCode = response.statusCode();
			String statusName = response.statusLine();
			System.out.println("RESULT GetDomainMalwareScanningReport: "+result);
			System.out.println("STATUS CODE : "+statusCode);
			System.out.println("STATUS NAME : "+statusName+"\n");
			
			Assert.assertTrue(result.contains("watchc01.000webhostapp.com"));
	}
	
	
	//---------GetDomainReputationReport
	
	@Test (priority = 3)
	  public void testGetDomainReputationReport(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
		  
			Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7125214");
		
		    String url = "http://service.cwatch.com/domains/1502/reports?type=2";
		   
		    Response response = callGetMethodPHP(url);
			String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
			int statusCode = response.statusCode();
			String statusName = response.statusLine();
			System.out.println("RESULT GetDomainReputationReport: "+result);
			System.out.println("STATUS CODE : "+statusCode);
			System.out.println("STATUS NAME : "+statusName+"\n");
			
			Assert.assertTrue(result.contains("watchc01.000webhostapp.com"));
	}
	
	
	//---------MalwareScanHistoryReport
	
	@Test (priority = 4)
	  public void testGetMalwareScanHistoryReport(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
		  
			Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7125219");
		
		    String url = " http://service.cwatch.com/scan_history/d2F0Y2hjMDEuMDAwd2ViaG9zdGFwcC5jb20=";
		   
		    Response response = callGetMethodPHP(url);
			String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
			int statusCode = response.statusCode();
			String statusName = response.statusLine();
			System.out.println("RESULT GetMalwareScanHistoryReport: "+result);
			System.out.println("STATUS CODE : "+statusCode);
			System.out.println("STATUS NAME : "+statusName+"\n");
			
			Assert.assertTrue(result.contains("watchc01.000webhostapp.com"));
	}
	
	
	//--------UpdateMalwareAutoRemovalFlag
	
	@Test (priority = 5)
	  public void testPatchUpdateMalwareAutoRemovalFlag(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
	   
		  Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7125228");
		
		  String api_url = "http://service.cwatch.com/domains/d2F0Y2hjMDEuMDAwd2ViaG9zdGFwcC5jb20=";
		  String api_body = "{\"customer\": {\"cam_id\": \"885829\"}, \"domain\": {\"auto_malware_removal\": true}}";
		  
		  Response response = callPatchMethod(api_body,api_url);
		  int statusCode = response.statusCode();
		  String statusName = response.statusLine();
		  System.out.println("PatchUpdateMalwareAutoRemovalFlag");
		  System.out.println("STATUS CODE : "+statusCode);
		  System.out.println("STATUS NAME : "+statusName+"\n");
		  
		  Assert.assertEquals("HTTP/1.1 200 OK",statusName);
	     
	  }
	
	
	//---------UpdateMalwareNotifierFlag
	
	@Test (priority = 6)
	  public void testPatchUpdateMalwareNotifierFlag(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
	   
		  Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7125236");
		
		  String api_url = "http://service.cwatch.com/domains/d2F0Y2hjMDEuMDAwd2ViaG9zdGFwcC5jb20=";
		  String api_body = "{\"customer\": {\"cam_id\": \"885829\"}, \"domain\": {\"malware_notifier\": true}}";
		  
		  Response response = callPatchMethod(api_body,api_url);
		  int statusCode = response.statusCode();
		  String statusName = response.statusLine();
		  System.out.println("PatchUpdateMalwareNotifierFlag");
		  System.out.println("STATUS CODE : "+statusCode);
		  System.out.println("STATUS NAME : "+statusName+"\n");
	     
		  Assert.assertEquals("HTTP/1.1 200 OK",statusName);
	  }
	
	
	//---------ScheduleScan
	
	@Test(priority = 7)
	  public void testPostScheduleScan(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
		  
		  Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7125238");
		
		  String api_url = "http://service.cwatch.com/scan";
		  String api_body = "{\"domain\": \"yetanothersite.us\", \"schedule\": true}";
		  
		  Response response = callPostMethodPHP(api_body,api_url);
		  String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
		  int statusCode = response.statusCode();
		  String statusName = response.statusLine();
		  System.out.println("RESULT ScheduleScan: "+result);
		  System.out.println("STATUS CODE : "+statusCode);
		  System.out.println("STATUS NAME : "+statusName+"\n");
		  
		  Assert.assertTrue(result.contains("Schedule scan turned on"));
	}
	
	
	//---------ImmediateScan
	
	@Test(priority = 8)
	  public void testPostImmediateScan(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
		  
		  Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7125240");
		
		  String api_url = "http://service.cwatch.com/scan";
		  String api_body = "{\"domain\": \"yetanothersite.us\", \"scan_type\": \"all\"}";
		  
		  Response response = callPostMethodPHP(api_body,api_url);
		  String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
		  int statusCode = response.statusCode();
		  String statusName = response.statusLine();
		  System.out.println("RESULT ImmediateScan: "+result);
		  System.out.println("STATUS CODE : "+statusCode);
		  System.out.println("STATUS NAME : "+statusName+"\n");
		  
		  Assert.assertTrue(result.contains("Reputation/Malware Scan task created for domain yetanothersite.us"));
	}
	
	
	//---------ImmediateScheduleScan
	
	@Test(priority = 9)
	  public void testPostImmediateScheduleScan(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
		  
		  Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7125243");
		
		  String api_url = "http://service.cwatch.com/scan";
		  String api_body = "{\"domain\": \"yetanothersite.us\", \"scan_type\": \"all\", \"schedule\": true}";
		  
		 // given().contentType("application/json; charset=UTF-8").body(api_body).when().post(api_url).then().statusCode(200);
		  
		  Response response = callPostMethodPHP(api_body,api_url);
		  String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
		  int statusCode = response.statusCode();
		  String statusName = response.statusLine();
		  System.out.println("RESULT ImmediateScheduleScan: "+result);
		  System.out.println("STATUS CODE : "+statusCode);
		  System.out.println("STATUS NAME : "+statusName+"\n");
		  
		  Assert.assertTrue(result.contains("Reputation/Malware Scan task created for domain"));
	}
	
	
	//---------GetScanInfo
	
	@Test (priority = 10)
	  public void testGetScanInfo(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
		  
			Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7125244");
		
		    String url = "http://service.cwatch.com/scan/d2F0Y2hjMDEuMDAwd2ViaG9zdGFwcC5jb20=";
		   
		    Response response = callGetMethodPHP(url);
			String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
			int statusCode = response.statusCode();
			String statusName = response.statusLine();
			System.out.println("RESULT GetScanInfo: "+result);
			System.out.println("STATUS CODE : "+statusCode);
			System.out.println("STATUS NAME : "+statusName+"\n");
			
			Assert.assertTrue(result.contains("watchc01.000webhostapp.com"));
	}
}
