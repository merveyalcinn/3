package com.comodo.api.test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import org.testng.Reporter;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;

import org.testng.annotations.Test;
import com.jayway.restassured.response.Response;
import junit.framework.Assert;

import com.comodo.api.test.TestRailIntegration;
import com.comodo.api.test.testRail_APIException;

/*import static com.jayway.restassured.RestAssured.given;
import org.testng.annotations.BeforeClass;

import static com.jayway.restassured.RestAssured.*;
import com.jayway.restassured.RestAssured;


import java.util.HashMap;
import java.util.Map;*/

public class testCreateCustomer extends CreateCustomer {
	
	 @AfterMethod
	    public void afterMethod(ITestResult result)
	    {
	    	TestRailIntegration test = new TestRailIntegration(TESTRAIL_USER,TESTRAIL_PASS);
	    	String case_id = result.getAttribute(result.getName()).toString();
	        try
	     {
	        if(result.getStatus() == ITestResult.SUCCESS)
	        {
	        	test.setResultToTestRail("63641", case_id, 1, "Passed in automation successfully");
	        	System.out.println("Pass");
	        }

	        else if(result.getStatus() == ITestResult.FAILURE)
	        {
	        	test.setResultToTestRail("63641", case_id, 5, "Failed in automation");
	        }

	         else if(result.getStatus() == ITestResult.SKIP ){

	        	test.setResultToTestRail("63641", case_id, 3, "Skipped in automation");
	        }
	    }
	       catch(Exception e)
	       {
	         e.printStackTrace();
	       }

	    }

	 
	
	//---------CreateCustomer
	
  @Test(priority = 1)
  public void testPostCreateCustomer(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
	  
	  Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7123968");
	  
	  String api_url = "http://service.cwatch.com/customers/";
	  String api_body ="{\"customer\":{\"licenses_attributes\": [ { \"key\":\"fb420ad9-c522-4b57-b481-e5bea5bf0f67\" } ], \"domains\": [\"rail.com\"] }}";
	   
	  Response response = callPostMethodAPI(api_body,api_url);
	  String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
	  int statusCode = response.statusCode();
	  String statusName = response.statusLine();
	  System.out.println("RESULT CreateCustomer: "+result);
	  System.out.println("STATUS CODE : "+statusCode);
	  System.out.println("STATUS NAME : "+statusName+"\n");
	  
	  Assert.assertTrue(result.contains("Customer created"));
	
  }
	
	
  //---------GetCustomerInfo
  
  @Test (priority = 2)
  public void testGetCustomerInfo(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
	  
	  	Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7124853");
	  
	    String url = "http://service.cwatch.com/customers/885829";
	    Response response = callGetAPI(url);
		String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
		int statusCode = response.statusCode();
		String statusName = response.statusLine();
		System.out.println("RESULT GetCustomerInfo: "+result);
		System.out.println("STATUS CODE : "+statusCode);
		System.out.println("STATUS NAME : "+statusName+"\n");
		
		Assert.assertTrue(result.contains("cwatchdemo_user2@yopmail.com"));
  }
  
  
  
  //---------GetAllCustomer
  
  @Test (priority = 3)
  public void testGetAllCustomer(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
	  
	  	Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7124963");
	  
	    String url = "http://service.cwatch.com/customers";
	   
	    Response response = callGetAPI(url);
		String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
		int statusCode = response.statusCode();
		String statusName = response.statusLine();
		System.out.println("RESULT GetAllCustomerInfo: "+result);
		System.out.println("STATUS CODE : "+statusCode);
		System.out.println("STATUS NAME : "+statusName+"\n");
		
		Assert.assertTrue(result.contains("cwatchdemo_user2@yopmail.com"));
  }
  
  
  
  //---------GetAllActiveCustomer
  
  @Test (priority = 4)
  public void testGetAllActiveCustomer(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
	  
	    Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7124964");
	    
	    String url = "http://service.cwatch.com/partners/2/customers?fb=domain&q=fowler";
	   
	    Response response = callGetAPI(url);
		String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
		int statusCode = response.statusCode();
		String statusName = response.statusLine();
		System.out.println("RESULT GetAllActiveCustomer: "+result);
		System.out.println("STATUS CODE : "+statusCode);
		System.out.println("STATUS NAME : "+statusName+"\n");
		
		Assert.assertTrue(result.contains("fowlercwatch.com"));
  }
  
  

  //---------RegisterDomainUpdateLicence
  
  @Test (priority = 5)
  public void testPatchRegisterDomainUpdateLicence(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
   
	  Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7124968");
	  
	  String api_url = " http://service.cwatch.com/customers/895266";
	  String api_body = "{\"customer\":{ \"licenses_attributes\": [ { \"key\":\"66ac2624-b133-46cd-b204-bf6bba3a3e09\" } ], \"domains\": [\"google-gruyere.appspot.com\"] }}";
   
	  Response response = callPatchMethod(api_body,api_url);
	  String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
	  int statusCode = response.statusCode();
	  String statusName = response.statusLine();
	  System.out.println("RESULT PatchRegisterDomain/UpdateLicence: "+result);
	  System.out.println("STATUS CODE : "+statusCode);
	  System.out.println("STATUS NAME : "+statusName+"\n");
	  
	  Assert.assertTrue(result.contains("Customer license/domains updated"));
     
  }
  
  
  
  //---------CREATE WEBSITE
  
  @Test(priority = 6)
  public void testPostCreateWebsite(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
	  
	  Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7124978");
	  
	  String api_url = "http://service.cwatch.com/cdn/2/sites ";
	  String api_body = "{\"domain\": {\"url\": \"http://kitap.com/\", \"prefix\": \"cdn\", \"custom_host_header\":\"kitap.com\", \"ips\": \"67.227.226.240,67.227.226.241,67.227.226.242\"}}";
	  
	  
	  Response response = callPostMethodAPI(api_body,api_url);
	  String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
	  int statusCode = response.statusCode();
	  String statusName = response.statusLine();
	  System.out.println("RESULT CreateWebsite: "+result);
	  System.out.println("STATUS CODE : "+statusCode);
	  System.out.println("STATUS NAME : "+statusName+"\n");
	  
	  Assert.assertTrue(result.contains("kitap.com"));
}
  
  
  //---------GetDomainInfo
  
  @Test (priority = 7)
  public void testGetDomainInfo(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
	  
	  	Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7124979");
	  
	    String url = "http://service.cwatch.com/domains?fb=domain&q=watchc01.000webhostapp.com";
	   
	    Response response = callGetAPI(url);
		String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
		int statusCode = response.statusCode();
		String statusName = response.statusLine();
		System.out.println("RESULT GetDomainInfo: "+result);
		System.out.println("STATUS CODE : "+statusCode);
		System.out.println("STATUS NAME : "+statusName+"\n");
		
		Assert.assertTrue(result.contains("watchc01.000webhostapp.com"));
  }
  
  
  
  //---------GetListAllWebsite
  
  @Test (priority = 8)
  public void testGetListAllWebsite(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
	  
	  	Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7124980");
	  
	    String url = "http://service.cwatch.com/cdn/2/sites";
	   
	    Response response = callGetAPI(url);
		String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
		int statusCode = response.statusCode();
		String statusName = response.statusLine();
		System.out.println("RESULT GetListAllWebsite: "+result);
		System.out.println("STATUS CODE : "+statusCode);
		System.out.println("STATUS NAME : "+statusName+"\n");
		
		Assert.assertTrue(result.contains("yetanothersite.us"));
  }
  
  
 
  //---------GetListWebsiteParameters
  
  @Test (priority = 9)
  public void testGetListWebsiteParameters(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
	  
	  	Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7124981");
	  
	    String url = "http://service.cwatch.com/cdn/sites/dGVzdHBocC52dWxud2ViLmNvbQ==";
	  
	    Response response = callGetAPI(url);
		String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
		int statusCode = response.statusCode();
		String statusName = response.statusLine();
		System.out.println("RESULT GetListWebsiteParameters: "+result);
		System.out.println("STATUS CODE : "+statusCode);
		System.out.println("STATUS NAME : "+statusName+"\n");
		
		Assert.assertTrue(result.contains("cdn_domain"));
  }
  
  
  
  //---------UpdateWebsite
  
  @Test (priority = 10)
  public void testPatchUpdateWebsite(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
   
	  Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7125010");
	  
	  String api_url = "http://service.cwatch.com/cdn/sites/ZXhhbXBsZS5jb20=";
	  String api_body = "{\"domain\": {\"url\": \"https://example.com:8080/\", \"custom_host_header\":\"example.com\", \"ips\": \"8.8.8.8\"}}";
	  
	  Response response = callPatchMethod(api_body,api_url);
	  String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
	  int statusCode = response.statusCode();
	  String statusName = response.statusLine();
	  System.out.println("RESULT PatchUpdateWebsite: "+result);
	  System.out.println("STATUS CODE : "+statusCode);
	  System.out.println("STATUS NAME : "+statusName+"\n");
	  
	  Assert.assertTrue(result.contains("example.com"));
     
  }
  
 

}
