package com.comodo.api.test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import org.testng.Reporter;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;

import org.testng.annotations.Test;
import com.jayway.restassured.response.Response;

import junit.framework.Assert;

import com.comodo.api.test.TestRailIntegration;
import com.comodo.api.test.testRail_APIException;


public class testStep_Delete extends Step_Delete {
	
	 @AfterMethod
	    public void afterMethod(ITestResult result)
	    {
	
		   
	    	TestRailIntegration test = new TestRailIntegration(TESTRAIL_USER,TESTRAIL_PASS);
	    	String case_id = result.getAttribute(result.getName()).toString();
	        try
	     {
	        if(result.getStatus() == ITestResult.SUCCESS)
	        {

	        	test.setResultToTestRail("63641", case_id, 1, "Passed in automation successfully");
	        	System.out.println("Pass");
	        
	        
	        }

	        else if(result.getStatus() == ITestResult.FAILURE)
	        {
	        	test.setResultToTestRail("63641", case_id, 5, "Failed in automation");
	      

	        }

	         else if(result.getStatus() == ITestResult.SKIP ){

	        	test.setResultToTestRail("63641", case_id, 3, "Skipped in automation");
	        	

	        }
	    }
	       catch(Exception e)
	       {
	         e.printStackTrace();
	       }

	    }

	 
	//--------Delete Website
	
		@Test (priority = 1)
		public void testDeleteWebsite(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
			  
			Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7128915");
			
			String url = "http://service.cwatch.com/domains/dGFzLmNvbQ=="; 
			   
		    Response response = callDeleteMethod(url);
			int statusCode = response.statusCode();
			String statusName = response.statusLine();
			System.out.println("RESULT testDeleteWebsite: ");
			System.out.println("STATUS CODE : "+statusCode);
			System.out.println("STATUS NAME : "+statusName+"\n");
			
			Assert.assertEquals("HTTP/1.1 200 OK",statusName);
			
		}
	
	//--------Delete Domain
	
	@Test (priority = 2)
		public void testDeleteDomain(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
		
			Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7128919");
			
			String url = "http://service.cwatch.com/domains/c2lsLmNvbQ=="; 
		   
			Response response = callDeleteMethod(url);
			int statusCode = response.statusCode();
			String statusName = response.statusLine();
			System.out.println("RESULT testDeleteDomain: ");
			System.out.println("STATUS CODE : "+statusCode);
			System.out.println("STATUS NAME : "+statusName+"\n");
			
			Assert.assertEquals("HTTP/1.1 200 OK",statusName);
		
	}
	
	
	

}
