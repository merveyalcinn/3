package com.comodo.api.test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import org.testng.Reporter;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.jayway.restassured.response.Response;
import junit.framework.Assert;

import com.comodo.api.test.TestRailIntegration;
import com.comodo.api.test.testRail_APIException;

public class testFTPsettings extends FTPsettings {

	
	  @AfterMethod
	    public void afterMethod(ITestResult result)
	    {
	
		   
	    	TestRailIntegration test = new TestRailIntegration(TESTRAIL_USER,TESTRAIL_PASS);
	    	String case_id = result.getAttribute(result.getName()).toString();
	        try
	     {
	        if(result.getStatus() == ITestResult.SUCCESS)
	        {

	        	test.setResultToTestRail("63641", case_id, 1, "Passed in automation successfully");
	        	System.out.println("Pass");
	        
	        
	        }

	        else if(result.getStatus() == ITestResult.FAILURE)
	        {
	        	test.setResultToTestRail("63641", case_id, 5, "Failed in automation");
	      

	        }

	         else if(result.getStatus() == ITestResult.SKIP ){

	        	test.setResultToTestRail("63641", case_id, 3, "Skipped in automation");
	        	

	        }
	    }
	       catch(Exception e)
	       {
	         e.printStackTrace();
	       }

	    }

	  
	  
	//-----------UpdateFTPsettings
	
	@Test (priority = 1)
	  public void testPatchUpdateFTPsettings(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
	   
			Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7125246");
		
			String api_url = " http://service.cwatch.com/domains/eWV0YW5vdGhlcnNpdGUudXM=";
	   		String api_body = "{\"customer\": {\"cam_id\": \"885829\"}, \"domain\": {\"ftp\": {\"login\": \"yetanothersite.us\", \"password\": \"mrc12345\", \"host\": \"yetanothersite.us\", \"port\": 21, \"path\": \"/abc/abc\"}}}";
	  
	   		Response response = callPatchMethod(api_body,api_url);
	   		int statusCode = response.statusCode();
	   		String statusName = response.statusLine();
	   		System.out.println("PatchUpdateFTPsettings");
	   		System.out.println("STATUS CODE : "+statusCode);
	   		System.out.println("STATUS NAME : "+statusName+"\n");
	   		
	   		Assert.assertEquals("HTTP/1.1 200 OK",statusName);
	     
	  }
	  
	
	//-----------GetFTPsettings
	
	@Test (priority = 2)
	  public void testGetFTPsettings(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException {
		
			Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7128914");
		  
		    String url = "http://service.cwatch.com/domains/YWxpaXkuY29t";
		   
		    Response response = callGetMethodFTP(url);
			String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
			int statusCode = response.statusCode();
			String statusName = response.statusLine();
			System.out.println("RESULT GetFTPsettings: "+result);
			System.out.println("STATUS CODE : "+statusCode);
			System.out.println("STATUS NAME : "+statusName+"\n");
			
			Assert.assertTrue(result.contains("aliiy.com"));
	}
	
}
