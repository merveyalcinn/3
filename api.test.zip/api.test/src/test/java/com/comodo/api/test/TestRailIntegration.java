package com.comodo.api.test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;


import com.comodo.api.test.testRail_APIClient;
import com.comodo.api.test.testRail_APIException;
import com.comodo.api.test.Variables;


public class TestRailIntegration extends Variables {
	
	private static String username;
	private static String password;
	
	public TestRailIntegration(String user_name, String pass){
		username = user_name;
		password = pass;
		
	}
	public void getResultFromTestRail(String case_id) throws MalformedURLException, IOException, testRail_APIException
	{ 
		testRail_APIClient client = new testRail_APIClient(TESTRAIL_URL);
		client.setUser(username);
		client.setPassword(password);
		JSONObject c = (JSONObject) client.sendGet("get_case/" + case_id);
		System.out.println(c.get("title"));
		
	}
	

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void setResultToTestRail(String run_id, String case_id,int status_id, String comment) throws MalformedURLException, IOException, testRail_APIException
	{
		testRail_APIClient client = new testRail_APIClient(TESTRAIL_URL);
		client.setUser(username);
		client.setPassword(password);
		Map data = new HashMap();
		data.put("status_id", new Integer(status_id));
	/** 1	Passed
		2	Blocked
		3	Untested (not allowed when adding a result)
		4	Retest
		5	Failed **/
		data.put("comment", comment);
		@SuppressWarnings("unused")
		JSONObject r = (JSONObject) client.sendPost("add_result_for_case/"+ run_id+"/"+case_id, data);
		//ilk alan run_id ikinci alan case_id
	}
}
