package com.comodo.api.test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import org.testng.Reporter;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;

import org.testng.annotations.Test;
import com.jayway.restassured.response.Response;
import junit.framework.Assert;

import com.comodo.api.test.TestRailIntegration;
import com.comodo.api.test.testRail_APIException;


public class testCreateCertificate extends CreateCertificate{
	
	@AfterMethod
    public void afterMethod(ITestResult result)
    {

	   
    	TestRailIntegration test = new TestRailIntegration(TESTRAIL_USER,TESTRAIL_PASS);
    	String case_id = result.getAttribute(result.getName()).toString();
        try
     {
        if(result.getStatus() == ITestResult.SUCCESS)
        {

        	test.setResultToTestRail("63641", case_id, 1, "Passed in automation successfully");
        	System.out.println("Pass");
        
        
        }

        else if(result.getStatus() == ITestResult.FAILURE)
        {
        	test.setResultToTestRail("63641", case_id, 5, "Failed in automation");
      

        }

         else if(result.getStatus() == ITestResult.SKIP ){

        	test.setResultToTestRail("63641", case_id, 3, "Skipped in automation");
        	

        }
    }
       catch(Exception e)
       {
         e.printStackTrace();
       }

    }
	
	
	//-----------CreateCertificate
	
	@Test(priority = 1) 
	  public void testPostCreateCertificate(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException  {
		  
		  Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7128927");
		
		  String api_url = "http://service.cwatch.com/cdn/2/certificates";
		  
		String api_body = "{\"domain\": {\"name\": \"yetanothersite.us\", \"certificate_name\":\"yetanothersite_us.crt\", \"certificate\": \"-----BEGIN CERTIFICATE-----"+
"MIIFVjCCBD6gAwIBAgIQS3ntt/WsIT9evz9nrK/EzTANBgkqhkiG9w0BAQsFADCB"+
"kDELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3RlcjEQMA4G"+
"A1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQxNjA0BgNV"+
"BAMTLUNPTU9ETyBSU0EgRG9tYWluIFZhbGlkYXRpb24gU2VjdXJlIFNlcnZlciBD"+
"QTAeFw0xNzEwMTAwMDAwMDBaFw0xODEwMTAyMzU5NTlaMFQxITAfBgNVBAsTGERv"+
"bWFpbiBDb250cm9sIFZhbGlkYXRlZDETMBEGA1UECxMKQ09NT0RPIFNTTDEaMBgG"+
"A1UEAxMReWV0YW5vdGhlcnNpdGUudXMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw"+
"ggEKAoIBAQDItiIv9HStEvE3cpFiRFawyoUbdGrLjNZUZgdhXXS2gzymUX145tRn"+
"MAbNZOVZnxcIU82nENpNRKd3OOxBz8oibA3Q7N+p9UlyD7bwViiR4aCWFSk+lWd9"+
"6QhSvGfb3ShToBtOaEEmmsdKlpQB6ChQF66rTtcjfTaHy2KE2/mP1JRckRhmKMU1"+
"PeK/IEVB52+Ay8/pQ2sSkasTVqHe2h4aMcmOp80BAx48q4dkIlScT6ptLaUPOGGZ"+
"nd6To1p+eyTc1OVVttoc/g40NnG7cENfbQ4k2MAb2JNXBR4J1LPoPOgRUOZ3mD0u"+
"xP6PiMAJTcPXxTdvn9f2QdjGuZitOVJHAgMBAAGjggHlMIIB4TAfBgNVHSMEGDAW"+
"gBSQr2o6lFoL2JDqElZz30O0Oija5zAdBgNVHQ4EFgQUxcRgnYasnqNaZte3aw9V"+
"sKAlVqgwDgYDVR0PAQH/BAQDAgWgMAwGA1UdEwEB/wQCMAAwHQYDVR0lBBYwFAYI"+
"KwYBBQUHAwEGCCsGAQUFBwMCME8GA1UdIARIMEYwOgYLKwYBBAGyMQECAgcwKzAp"+
"BggrBgEFBQcCARYdaHR0cHM6Ly9zZWN1cmUuY29tb2RvLmNvbS9DUFMwCAYGZ4EM"+
"AQIBMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly9jcmwuY29tb2RvY2EuY29tL0NP"+
"TU9ET1JTQURvbWFpblZhbGlkYXRpb25TZWN1cmVTZXJ2ZXJDQS5jcmwwgYUGCCsG"+
"AQUFBwEBBHkwdzBPBggrBgEFBQcwAoZDaHR0cDovL2NydC5jb21vZG9jYS5jb20v"+
"Q09NT0RPUlNBRG9tYWluVmFsaWRhdGlvblNlY3VyZVNlcnZlckNBLmNydDAkBggr"+
"BgEFBQcwAYYYaHR0cDovL29jc3AuY29tb2RvY2EuY29tMDMGA1UdEQQsMCqCEXll"+
"dGFub3RoZXJzaXRlLnVzghV3d3cueWV0YW5vdGhlcnNpdGUudXMwDQYJKoZIhvcN"+
"AQELBQADggEBAB1h8ylGVuEmO3o8f8BwTfz6S+WyTHqnLT/6r+q1c1pWyLppOLmT"+
"xJuqqxk8QCcX5isqWf9KuVu/sVUW61RWTWA/lvhXOrFwavPr+OHqTVUmjRuBZH/n"+
"GFQuzwafviYrlNT/fTkTikHprBdcr5oP81kZgQWgQT5D5POShnIhq3qzuMEMjI0y"+
"2yn9kAx7hjuj146MhldzVzrDQ8TeTL3JjDZqs1FqsaaZHL5Ee+JaaFOJj/C8focO"+
"niPvFx0Atnz4C6f9UiLV+aSZS01GfydhdU3X5BdOAvclOxuwCTNlwLQKVDUNERWp"+
"vw1C3DXbqIE9xiLiespc7lQVLJ6W1lr/Dhg="+
"-----END CERTIFICATE-----\", \"private_key\": \"-----BEGIN RSA PRIVATE KEY-----"+
"MIIEpQIBAAKCAQEAyLYiL/R0rRLxN3KRYkRWsMqFG3Rqy4zWVGYHYV10toM8plF9"+
"eObUZzAGzWTlWZ8XCFPNpxDaTUSndzjsQc/KImwN0OzfqfVJcg+28FYokeGglhUp"+
"PpVnfekIUrxn290oU6AbTmhBJprHSpaUAegoUBeuq07XI302h8tihNv5j9SUXJEY"+
"ZijFNT3ivyBFQedvgMvP6UNrEpGrE1ah3toeGjHJjqfNAQMePKuHZCJUnE+qbS2l"+
"DzhhmZ3ek6Nafnsk3NTlVbbaHP4ONDZxu3BDX20OJNjAG9iTVwUeCdSz6DzoEVDm"+
"d5g9LsT+j4jACU3D18U3b5/X9kHYxrmYrTlSRwIDAQABAoIBAQCS2/m93v+0V+TZ"+
"7mGEZn6ME1M72H3//EgjLxh9XJV2qiYph/zoBvYpnpGLniTW47pFpJQYhxNEcFSc"+
"vrDYIsNDVo7xbTDmugyIggkYZ+J9g3st9cPdABLepTEq4KKZ1IOaVM9GGrB5H81s"+
"vSsFDirZF8r9m819MTRCPkYS8qXzX4tDbJiWtvOFRbmRDiklPjKMptvrGWfrSEG2"+
"V7o12XJwr9yBdRZ8lDzv14GRxCgeGvXkuwiSDofAr9UL4t+aQDB0nxLdYqlVJzcV"+
"/bRccVdmMXLKWLQpRkOIuFohPtAnv1L09yhx5aR+c38v5pcwc5JQYDqnT4Qa8jtQ"+
"Pys+LbRZAoGBAOwm6UftQgk4u6ij0/Y0nOddaN/1CGUil7k30L/IPnVObmjrZtTE"+
"knRsvkDJOT8aq65M7iezTnMFOYbq+QmiybyA4W56RDF2rhxvvzv4QF8UZa9Adjz1"+
"8WDjppCIUbZbJM2F8dlmvpl6y96mMINWpQQJ670eOE4iuULF/9+e14ptAoGBANmU"+
"rWSgWFURgmCX7v65zK/fuoz87kEs/WS8G8l4GOqdRf1cMcKqWLTaGC37cvrKdUce"+
"Th7+gSRxz5yN8jv9NEoUcui+BjZ4MeMUeG+dmu5F+VdNQhlkK3kTFsmLpmCrUYr3"+
"tiBIyt70iEvNkx2YX5XkLuOn1FofsQ/AYfA0/Z8DAoGAZ4nP8idGMsDbFl9uCZ6b"+
"xJ0h5D+MxLrcBus/7TYgnFIc+odreJIPHFipOcKABPjumOdF68Yj+S4rQMo5Ek57"+
"YNio/kVBLOa6A+HC2MpJfuZ0htgefy/d+vsVBn2eRfPEORAnL4hqvOQoCqCW2J7e"+
"jtzCrRJY4Xk7/NjPDP6ZxikCgYEAkTEyp+SMLXA6tWSNunOYEIDWhwC9qMZx7UfN"+
"rxqyXdVHgDOGjSWJfl3PJtgVuR9jNWsWrH4fBYfhB9J9I+TqgMi2iXNMyApbF/Jw"+
"D+N3IKuXINfQVQtQK0I+wY2sH/QSvQ5h/Zc1saQyU4tCMcyddHPJimdTQDTHvgAe"+
"GuHxoKsCgYEAnQtsr8HKrXwNSGPJ/366/bny0iyl8l58OrOPYESbQA3NhC5vrJV6"+
"ceri1yHhYXVB/fOWEHIEa0Dd8wOJYFwVhLs1yeXFBlPXJ10Sp5tpp1QeYNF8Td2b"+
"DG/k2rY+GQbsYEucTUDL2g0T1lc+DK7kk2a+01700kNbv/VPcV2S3io="+
"-----END RSA PRIVATE KEY-----\", \"chain\": \"-----BEGIN CERTIFICATE-----"+
"MIIFVjCCBD6gAwIBAgIQS3ntt/WsIT9evz9nrK/EzTANBgkqhkiG9w0BAQsFADCB"+
"kDELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3RlcjEQMA4G"+
"A1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQxNjA0BgNV"+
"BAMTLUNPTU9ETyBSU0EgRG9tYWluIFZhbGlkYXRpb24gU2VjdXJlIFNlcnZlciBD"+
"QTAeFw0xNzEwMTAwMDAwMDBaFw0xODEwMTAyMzU5NTlaMFQxITAfBgNVBAsTGERv"+
"bWFpbiBDb250cm9sIFZhbGlkYXRlZDETMBEGA1UECxMKQ09NT0RPIFNTTDEaMBgG"+
"A1UEAxMReWV0YW5vdGhlcnNpdGUudXMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw"+
"ggEKAoIBAQDItiIv9HStEvE3cpFiRFawyoUbdGrLjNZUZgdhXXS2gzymUX145tRn"+
"MAbNZOVZnxcIU82nENpNRKd3OOxBz8oibA3Q7N+p9UlyD7bwViiR4aCWFSk+lWd9"+
"6QhSvGfb3ShToBtOaEEmmsdKlpQB6ChQF66rTtcjfTaHy2KE2/mP1JRckRhmKMU1"+
"PeK/IEVB52+Ay8/pQ2sSkasTVqHe2h4aMcmOp80BAx48q4dkIlScT6ptLaUPOGGZ"+
"nd6To1p+eyTc1OVVttoc/g40NnG7cENfbQ4k2MAb2JNXBR4J1LPoPOgRUOZ3mD0u"+
"xP6PiMAJTcPXxTdvn9f2QdjGuZitOVJHAgMBAAGjggHlMIIB4TAfBgNVHSMEGDAW"+
"gBSQr2o6lFoL2JDqElZz30O0Oija5zAdBgNVHQ4EFgQUxcRgnYasnqNaZte3aw9V"+
"sKAlVqgwDgYDVR0PAQH/BAQDAgWgMAwGA1UdEwEB/wQCMAAwHQYDVR0lBBYwFAYI"+
"KwYBBQUHAwEGCCsGAQUFBwMCME8GA1UdIARIMEYwOgYLKwYBBAGyMQECAgcwKzAp"+
"BggrBgEFBQcCARYdaHR0cHM6Ly9zZWN1cmUuY29tb2RvLmNvbS9DUFMwCAYGZ4EM"+
"AQIBMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly9jcmwuY29tb2RvY2EuY29tL0NP"+
"TU9ET1JTQURvbWFpblZhbGlkYXRpb25TZWN1cmVTZXJ2ZXJDQS5jcmwwgYUGCCsG"+
"AQUFBwEBBHkwdzBPBggrBgEFBQcwAoZDaHR0cDovL2NydC5jb21vZG9jYS5jb20v"+
"Q09NT0RPUlNBRG9tYWluVmFsaWRhdGlvblNlY3VyZVNlcnZlckNBLmNydDAkBggr"+
"BgEFBQcwAYYYaHR0cDovL29jc3AuY29tb2RvY2EuY29tMDMGA1UdEQQsMCqCEXll"+
"dGFub3RoZXJzaXRlLnVzghV3d3cueWV0YW5vdGhlcnNpdGUudXMwDQYJKoZIhvcN"+
"AQELBQADggEBAB1h8ylGVuEmO3o8f8BwTfz6S+WyTHqnLT/6r+q1c1pWyLppOLmT"+
"xJuqqxk8QCcX5isqWf9KuVu/sVUW61RWTWA/lvhXOrFwavPr+OHqTVUmjRuBZH/n"+
"GFQuzwafviYrlNT/fTkTikHprBdcr5oP81kZgQWgQT5D5POShnIhq3qzuMEMjI0y"+
"2yn9kAx7hjuj146MhldzVzrDQ8TeTL3JjDZqs1FqsaaZHL5Ee+JaaFOJj/C8focO"+
"niPvFx0Atnz4C6f9UiLV+aSZS01GfydhdU3X5BdOAvclOxuwCTNlwLQKVDUNERWp"+
"vw1C3DXbqIE9xiLiespc7lQVLJ6W1lr/Dhg="+
"-----END CERTIFICATE-----\"}";
		  Response response = callPostMethodCC(api_body,api_url);
		  String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
		  int statusCode = response.statusCode();
		  String statusName = response.statusLine();
		  System.out.println("RESULT CreateCertificate: "+result);
		  System.out.println("STATUS CODE : "+statusCode);
		  System.out.println("STATUS NAME : "+statusName+"\n");
		  
		  Assert.assertEquals("HTTP/1.1 200 OK",statusName);
	}
	
	
	//-----------ListAllCertificate
	
	@Test (priority = 2)
	  public void testGetListAllCertificate(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException  {
		  
			Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7128928");
		
		    String url = "http://service.cwatch.com/cdn/2/certificates";
		   
		    Response response = callGetCC(url);
			String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
			int statusCode = response.statusCode();
			String statusName = response.statusLine();
			System.out.println("RESULT GetListAllCertificate: "+result);
			System.out.println("STATUS CODE : "+statusCode);
			System.out.println("STATUS NAME : "+statusName+"\n");
			
			Assert.assertEquals("HTTP/1.1 200 OK",statusName);
	}
	
	
	//----------ListCertificateForDomain
	
	@Test (priority = 3)
	  public void testGetListCertificateForDomain(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException  {
		  
			Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7128930");
		
		    String url = "http://service.cwatch.com/cdn/certificates/eWV0YW5vdGhlcnNpdGUudXM=";
		   
		    Response response = callGetCC(url);
			String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
			int statusCode = response.statusCode();
			String statusName = response.statusLine();
			System.out.println("RESULT GetListCertificateForDomain: "+result);
			System.out.println("STATUS CODE : "+statusCode);
			System.out.println("STATUS NAME : "+statusName+"\n");
			
			Assert.assertTrue(result.contains("yetanothersite.us"));
	}
	
	
	//----------UpdateCertificate
	
	@Test (priority = 4)
	  public void testPatchUpdateCertificate(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException  {
	   
		  Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7128931");
		
		  String api_url = "http://service.cwatch.com/cdn/certificates/eWV0YW5vdGhlcnNpdGUudXM=";
		  String api_body ="{\"domain\": {\"certificate\": \"-----BEGIN CERTIFICATE-----"+
				  "MIIFVjCCBD6gAwIBAgIQS3ntt/WsIT9evz9nrK/EzTANBgkqhkiG9w0BAQsFADCB"+
				  "kDELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3RlcjEQMA4G"+
				  "A1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQxNjA0BgNV"+
				  "BAMTLUNPTU9ETyBSU0EgRG9tYWluIFZhbGlkYXRpb24gU2VjdXJlIFNlcnZlciBD"+
				  "QTAeFw0xNzEwMTAwMDAwMDBaFw0xODEwMTAyMzU5NTlaMFQxITAfBgNVBAsTGERv"+
				  "bWFpbiBDb250cm9sIFZhbGlkYXRlZDETMBEGA1UECxMKQ09NT0RPIFNTTDEaMBgG"+
				  "A1UEAxMReWV0YW5vdGhlcnNpdGUudXMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw"+
				  "ggEKAoIBAQDItiIv9HStEvE3cpFiRFawyoUbdGrLjNZUZgdhXXS2gzymUX145tRn"+
				  "MAbNZOVZnxcIU82nENpNRKd3OOxBz8oibA3Q7N+p9UlyD7bwViiR4aCWFSk+lWd9"+
				  "6QhSvGfb3ShToBtOaEEmmsdKlpQB6ChQF66rTtcjfTaHy2KE2/mP1JRckRhmKMU1"+
				  "PeK/IEVB52+Ay8/pQ2sSkasTVqHe2h4aMcmOp80BAx48q4dkIlScT6ptLaUPOGGZ"+
				  "nd6To1p+eyTc1OVVttoc/g40NnG7cENfbQ4k2MAb2JNXBR4J1LPoPOgRUOZ3mD0u"+
				  "xP6PiMAJTcPXxTdvn9f2QdjGuZitOVJHAgMBAAGjggHlMIIB4TAfBgNVHSMEGDAW"+
				  "gBSQr2o6lFoL2JDqElZz30O0Oija5zAdBgNVHQ4EFgQUxcRgnYasnqNaZte3aw9V"+
				  "sKAlVqgwDgYDVR0PAQH/BAQDAgWgMAwGA1UdEwEB/wQCMAAwHQYDVR0lBBYwFAYI"+
				  "KwYBBQUHAwEGCCsGAQUFBwMCME8GA1UdIARIMEYwOgYLKwYBBAGyMQECAgcwKzAp"+
				  "BggrBgEFBQcCARYdaHR0cHM6Ly9zZWN1cmUuY29tb2RvLmNvbS9DUFMwCAYGZ4EM"+
				  "AQIBMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly9jcmwuY29tb2RvY2EuY29tL0NP"+
				  "TU9ET1JTQURvbWFpblZhbGlkYXRpb25TZWN1cmVTZXJ2ZXJDQS5jcmwwgYUGCCsG"+
				  "AQUFBwEBBHkwdzBPBggrBgEFBQcwAoZDaHR0cDovL2NydC5jb21vZG9jYS5jb20v"+
				  "Q09NT0RPUlNBRG9tYWluVmFsaWRhdGlvblNlY3VyZVNlcnZlckNBLmNydDAkBggr"+
				  "BgEFBQcwAYYYaHR0cDovL29jc3AuY29tb2RvY2EuY29tMDMGA1UdEQQsMCqCEXll"+
				  "dGFub3RoZXJzaXRlLnVzghV3d3cueWV0YW5vdGhlcnNpdGUudXMwDQYJKoZIhvcN"+
				  "AQELBQADggEBAB1h8ylGVuEmO3o8f8BwTfz6S+WyTHqnLT/6r+q1c1pWyLppOLmT"+
				  "xJuqqxk8QCcX5isqWf9KuVu/sVUW61RWTWA/lvhXOrFwavPr+OHqTVUmjRuBZH/n"+
				  "GFQuzwafviYrlNT/fTkTikHprBdcr5oP81kZgQWgQT5D5POShnIhq3qzuMEMjI0y"+
				  "2yn9kAx7hjuj146MhldzVzrDQ8TeTL3JjDZqs1FqsaaZHL5Ee+JaaFOJj/C8focO"+
				  "niPvFx0Atnz4C6f9UiLV+aSZS01GfydhdU3X5BdOAvclOxuwCTNlwLQKVDUNERWp"+
				  "vw1C3DXbqIE9xiLiespc7lQVLJ6W1lr/Dhg="+
				  "-----END CERTIFICATE-----\", \"private_key\": \"-----BEGIN RSA PRIVATE KEY-----"+
				  "MIIEpQIBAAKCAQEAyLYiL/R0rRLxN3KRYkRWsMqFG3Rqy4zWVGYHYV10toM8plF9"+
				  "eObUZzAGzWTlWZ8XCFPNpxDaTUSndzjsQc/KImwN0OzfqfVJcg+28FYokeGglhUp"+
				  "PpVnfekIUrxn290oU6AbTmhBJprHSpaUAegoUBeuq07XI302h8tihNv5j9SUXJEY"+
				  "ZijFNT3ivyBFQedvgMvP6UNrEpGrE1ah3toeGjHJjqfNAQMePKuHZCJUnE+qbS2l"+
				  "DzhhmZ3ek6Nafnsk3NTlVbbaHP4ONDZxu3BDX20OJNjAG9iTVwUeCdSz6DzoEVDm"+
				  "d5g9LsT+j4jACU3D18U3b5/X9kHYxrmYrTlSRwIDAQABAoIBAQCS2/m93v+0V+TZ"+
				  "7mGEZn6ME1M72H3//EgjLxh9XJV2qiYph/zoBvYpnpGLniTW47pFpJQYhxNEcFSc"+
				  "vrDYIsNDVo7xbTDmugyIggkYZ+J9g3st9cPdABLepTEq4KKZ1IOaVM9GGrB5H81s"+
				  "vSsFDirZF8r9m819MTRCPkYS8qXzX4tDbJiWtvOFRbmRDiklPjKMptvrGWfrSEG2"+
				  "V7o12XJwr9yBdRZ8lDzv14GRxCgeGvXkuwiSDofAr9UL4t+aQDB0nxLdYqlVJzcV"+
				  "/bRccVdmMXLKWLQpRkOIuFohPtAnv1L09yhx5aR+c38v5pcwc5JQYDqnT4Qa8jtQ"+
				  "Pys+LbRZAoGBAOwm6UftQgk4u6ij0/Y0nOddaN/1CGUil7k30L/IPnVObmjrZtTE"+
				  "knRsvkDJOT8aq65M7iezTnMFOYbq+QmiybyA4W56RDF2rhxvvzv4QF8UZa9Adjz1"+
				  "8WDjppCIUbZbJM2F8dlmvpl6y96mMINWpQQJ670eOE4iuULF/9+e14ptAoGBANmU"+
				  "rWSgWFURgmCX7v65zK/fuoz87kEs/WS8G8l4GOqdRf1cMcKqWLTaGC37cvrKdUce"+
				  "Th7+gSRxz5yN8jv9NEoUcui+BjZ4MeMUeG+dmu5F+VdNQhlkK3kTFsmLpmCrUYr3"+
				  "tiBIyt70iEvNkx2YX5XkLuOn1FofsQ/AYfA0/Z8DAoGAZ4nP8idGMsDbFl9uCZ6b"+
				  "xJ0h5D+MxLrcBus/7TYgnFIc+odreJIPHFipOcKABPjumOdF68Yj+S4rQMo5Ek57"+
				  "YNio/kVBLOa6A+HC2MpJfuZ0htgefy/d+vsVBn2eRfPEORAnL4hqvOQoCqCW2J7e"+
				  "jtzCrRJY4Xk7/NjPDP6ZxikCgYEAkTEyp+SMLXA6tWSNunOYEIDWhwC9qMZx7UfN"+
				  "rxqyXdVHgDOGjSWJfl3PJtgVuR9jNWsWrH4fBYfhB9J9I+TqgMi2iXNMyApbF/Jw"+
				  "D+N3IKuXINfQVQtQK0I+wY2sH/QSvQ5h/Zc1saQyU4tCMcyddHPJimdTQDTHvgAe"+
				  "GuHxoKsCgYEAnQtsr8HKrXwNSGPJ/366/bny0iyl8l58OrOPYESbQA3NhC5vrJV6"+
				  "ceri1yHhYXVB/fOWEHIEa0Dd8wOJYFwVhLs1yeXFBlPXJ10Sp5tpp1QeYNF8Td2b"+
				  "DG/k2rY+GQbsYEucTUDL2g0T1lc+DK7kk2a+01700kNbv/VPcV2S3io="+
				  "-----END RSA PRIVATE KEY-----\", \"chain\": \"-----BEGIN CERTIFICATE-----"+
				  "MIIFVjCCBD6gAwIBAgIQS3ntt/WsIT9evz9nrK/EzTANBgkqhkiG9w0BAQsFADCB"+
				  "kDELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3RlcjEQMA4G"+
				  "A1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQxNjA0BgNV"+
				  "BAMTLUNPTU9ETyBSU0EgRG9tYWluIFZhbGlkYXRpb24gU2VjdXJlIFNlcnZlciBD"+
				  "QTAeFw0xNzEwMTAwMDAwMDBaFw0xODEwMTAyMzU5NTlaMFQxITAfBgNVBAsTGERv"+
				  "bWFpbiBDb250cm9sIFZhbGlkYXRlZDETMBEGA1UECxMKQ09NT0RPIFNTTDEaMBgG"+
				  "A1UEAxMReWV0YW5vdGhlcnNpdGUudXMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw"+
				  "ggEKAoIBAQDItiIv9HStEvE3cpFiRFawyoUbdGrLjNZUZgdhXXS2gzymUX145tRn"+
				  "MAbNZOVZnxcIU82nENpNRKd3OOxBz8oibA3Q7N+p9UlyD7bwViiR4aCWFSk+lWd9"+
				  "6QhSvGfb3ShToBtOaEEmmsdKlpQB6ChQF66rTtcjfTaHy2KE2/mP1JRckRhmKMU1"+
				  "PeK/IEVB52+Ay8/pQ2sSkasTVqHe2h4aMcmOp80BAx48q4dkIlScT6ptLaUPOGGZ"+
				  "nd6To1p+eyTc1OVVttoc/g40NnG7cENfbQ4k2MAb2JNXBR4J1LPoPOgRUOZ3mD0u"+
				  "xP6PiMAJTcPXxTdvn9f2QdjGuZitOVJHAgMBAAGjggHlMIIB4TAfBgNVHSMEGDAW"+
				  "gBSQr2o6lFoL2JDqElZz30O0Oija5zAdBgNVHQ4EFgQUxcRgnYasnqNaZte3aw9V"+
				  "sKAlVqgwDgYDVR0PAQH/BAQDAgWgMAwGA1UdEwEB/wQCMAAwHQYDVR0lBBYwFAYI"+
				  "KwYBBQUHAwEGCCsGAQUFBwMCME8GA1UdIARIMEYwOgYLKwYBBAGyMQECAgcwKzAp"+
				  "BggrBgEFBQcCARYdaHR0cHM6Ly9zZWN1cmUuY29tb2RvLmNvbS9DUFMwCAYGZ4EM"+
				  "AQIBMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly9jcmwuY29tb2RvY2EuY29tL0NP"+
				  "TU9ET1JTQURvbWFpblZhbGlkYXRpb25TZWN1cmVTZXJ2ZXJDQS5jcmwwgYUGCCsG"+
				  "AQUFBwEBBHkwdzBPBggrBgEFBQcwAoZDaHR0cDovL2NydC5jb21vZG9jYS5jb20v"+
				  "Q09NT0RPUlNBRG9tYWluVmFsaWRhdGlvblNlY3VyZVNlcnZlckNBLmNydDAkBggr"+
				 " BgEFBQcwAYYYaHR0cDovL29jc3AuY29tb2RvY2EuY29tMDMGA1UdEQQsMCqCEXll"+
				 " dGFub3RoZXJzaXRlLnVzghV3d3cueWV0YW5vdGhlcnNpdGUudXMwDQYJKoZIhvcN"+
				  "AQELBQADggEBAB1h8ylGVuEmO3o8f8BwTfz6S+WyTHqnLT/6r+q1c1pWyLppOLmT"+
				  "xJuqqxk8QCcX5isqWf9KuVu/sVUW61RWTWA/lvhXOrFwavPr+OHqTVUmjRuBZH/n"+
				  "GFQuzwafviYrlNT/fTkTikHprBdcr5oP81kZgQWgQT5D5POShnIhq3qzuMEMjI0y"+
				  "2yn9kAx7hjuj146MhldzVzrDQ8TeTL3JjDZqs1FqsaaZHL5Ee+JaaFOJj/C8focO"+
				  "niPvFx0Atnz4C6f9UiLV+aSZS01GfydhdU3X5BdOAvclOxuwCTNlwLQKVDUNERWp"+
				  "vw1C3DXbqIE9xiLiespc7lQVLJ6W1lr/Dhg="+
				 " -----END CERTIFICATE-----\"}}";
		  Response response = callPatchMethod(api_body,api_url);
		  String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
		  int statusCode = response.statusCode();
		  String statusName = response.statusLine();
		  System.out.println("RESULT PatchUpdateCertificate: "+result);
		  System.out.println("STATUS CODE : "+statusCode);
		  System.out.println("STATUS NAME : "+statusName+"\n");
		  
		  Assert.assertTrue(result.contains("www.yetanothersite.us"));
	     
	  }
	
	
	//----------DeleteCertificate
	
	@Test (priority = 5)
	  public void testDeleteCertificate(Method currentMethod) throws InterruptedException, MalformedURLException, IOException, testRail_APIException  {
		  
		  Reporter.getCurrentTestResult().setAttribute(currentMethod.getName(), "7128933");
		
		  String api_url = "http://service.cwatch.com/cdn/certificates ";
		  String api_body = "{\"domain\": {\"name\": \"yetanothersite.us\"}}";
			
		  Response response = callDeleteMethod(api_body,api_url);
		  String result = response.body().asString(); //asString() is used to convert a jsonValue to a Java String
		  int statusCode = response.statusCode();
		  String statusName = response.statusLine();
		  System.out.println("RESULT DeleteCertificate: "+result);
		  System.out.println("STATUS CODE : "+statusCode);
		  System.out.println("STATUS NAME : "+statusName+"\n");
		  
		  Assert.assertEquals("HTTP/1.1 200 OK",statusName);
	}
}
