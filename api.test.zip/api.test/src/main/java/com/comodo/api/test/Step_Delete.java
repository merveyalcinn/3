package com.comodo.api.test;

import static com.jayway.restassured.RestAssured.given;

import com.jayway.restassured.response.Response;

public class Step_Delete extends Variables {

	public Response callDeleteMethod(String url)
	  {

		 Response response = given().contentType("application/json; charset=UTF-8").when().delete(url);
		 return response;
	   
	  }
}
