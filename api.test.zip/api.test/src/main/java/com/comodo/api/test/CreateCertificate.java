package com.comodo.api.test;

import static com.jayway.restassured.RestAssured.given;

import com.jayway.restassured.response.Response;

public class CreateCertificate extends Variables{
	
	public Response callGetCC(String url)
    {
		Response response = given().contentType("application/json; charset=UTF-8").when().get(url);
		return response;
		
	}
	
	
	public Response callPostMethodCC(String APIBody, String APIUrl)
	{
		
		if(APIBody.contains("certificate_name"))
		{
			Response response = given().contentType("application/json; charset=UTF-8").accept("application/vnd.cwatch.v2").body(APIBody).when().post(APIUrl);
            return response;
		}
		else
		{
			Response response = given().contentType("application/json; charset=UTF-8").body(APIBody).when().post(APIUrl);
			return response;
		}

		 
		 
		
	}
	
	
	public Response callPatchMethod(String APIBody, String APIUrl)
	  {

		 Response response = given().contentType("application/json; charset=UTF-8").body(APIBody).when().patch(APIUrl);
		 return response;
	   
	  }
	
	public Response callDeleteMethod(String APIBody, String APIUrl)
	  {

		 Response response = given().contentType("application/json; charset=UTF-8").body(APIBody).when().delete(APIUrl);
		 return response;
	   
	  }

}
