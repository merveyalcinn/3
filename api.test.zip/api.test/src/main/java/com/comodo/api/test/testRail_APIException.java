package com.comodo.api.test;


@SuppressWarnings("serial")
public class testRail_APIException extends Exception {
	
	public testRail_APIException(String message)
	{
		super(message);
	}

}
