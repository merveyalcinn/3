package com.comodo.api.test;
//import java.util.Map;

import static com.jayway.restassured.RestAssured.given;

import com.jayway.restassured.response.Response;

public class FTPsettings extends Variables{
	
	public Response callGetMethodFTP(String url)
    {
		Response response = given().contentType("application/json; charset=UTF-8").when().get(url);
		return response;
		
	}
	
	
	public Response callPostMethodFTP(String APIBody, String APIUrl)
	{

		 Response response = given().contentType("application/json; charset=UTF-8").body(APIBody).when().post(APIUrl);
		 return response;
	
		
	}
	
	public Response callPatchMethod(String APIBody, String APIUrl)
	  {

		 Response response = given().contentType("application/json; charset=UTF-8").body(APIBody).when().patch(APIUrl);
		 return response;
	   
	  }

}
